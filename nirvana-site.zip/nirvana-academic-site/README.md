# Nirvana Coppola — personal academic website

A lightweight, responsive website designed for GitHub Pages. It uses plain HTML, CSS and JavaScript: no build step, framework, database, or paid service.

## Files

- `index.html` — page structure
- `content.js` — the only file you normally need to edit
- `assets/style.css` — visual design
- `assets/site.js` — renders the content and mobile navigation

## Publish on GitHub Pages

1. Create a **public** repository named exactly `NirvanaC93.github.io`.
2. Upload all files and folders from this project to the repository root (not inside an extra folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After GitHub finishes publishing, the site will be available at `https://nirvanac93.github.io`.

## Updating the site

Edit `content.js`. Add or change entries in `publications`, `talks`, `events`, and `teaching`. Each entry follows the examples already included in that file. Commit the changes; GitHub Pages republishes the site automatically.

For example:

```js
talks: [
  {
    date: "May 2026",
    title: "Title of the talk",
    event: "Conference or seminar",
    place: "City, Country",
    url: "https://example.com"
  }
],
```

Keep links as full `https://...` URLs. If an item has no public link, use an empty string or omit `url`.

## Assisted-update workflow (planned)

The site is deliberately approval-based: nothing should publish itself just because a new record is discovered. A later enhancement can add a scheduled check for ORCID and a review queue (for example, a GitHub issue or pull request) so that you can approve suggested changes before they appear on the public site.

## Before launch

The starter content intentionally avoids inventing biographical details, affiliations, dates, publication titles, or contact information. Review `content.js` and replace the draft descriptions, add verified links, and remove any topics that do not accurately describe your work.
